#!/usr/bin/env python
# coding: utf-8
# module with all DA functions

import numpy as np
import scipy as scipy
import scipy.stats as stats
import scipy.linalg as linalg
from pprint import pprint
import sys
import os
import copy
import string
import glob
#import xarray as xr 

import warnings

#################### Classes ######################

class Model(object):

    #---------------------------------------------------------------------------
    def __init__(self, num_time_steps, dt, IC, temporal_integration_method='runge-kutta',bias=None, amplitude=None, period=None, num_dump_steps=None, output_dir=None,forced=False):
        
        # Assign parameters
        self.num_time_steps  = num_time_steps  # length of time integration
        self.dt              = dt              # time step size
        self.ii_global       = 1               # time step counter
        self.ii              = 0               # time step counter reset when files are dumped
        self.IC              = IC              # initial conditions
        self.forced          = forced          # nonautonomous forcing
        self.temporal_integration_method = temporal_integration_method  # Euler or Runge-Kutta temporal integration
        self.num_states      = len(self.IC)    # number of states in model
        if num_dump_steps is not None:
            self.num_dump_steps = num_dump_steps # how often data is dumped to disk
        else:
            self.num_dump_steps = num_time_steps
        self.output_dir      = output_dir      # directory to which data is dumped to disk
        
        if bias is not None:                   # amplitude of time invariant bias
            self.bias        = bias
        else:
            self.bias        = np.array(np.zeros((self.num_states), dtype=np.float64))

        if amplitude is not None:              # amplitude of cyclic forcing
            self.amplitude   = amplitude
        else:
            self.amplitude   = np.array(np.zeros((self.num_states), dtype=np.float64))

        if period is not None:                 # period of cyclic forcing
            self.num_steps_in_period = (period/self.dt).astype(int)
            self.period      = self.dt*self.num_steps_in_period
        else:
            self.num_steps_in_period = None
            self.period      = np.array(np.ones((self.num_states), dtype=np.float64))

        self.states          = np.linspace(0,self.num_states-1,self.num_states)
        self.time            = np.array(np.zeros((self.num_dump_steps), dtype=np.float64))
        self.time_ind        = np.array(np.zeros((self.num_dump_steps), dtype=np.int64))
        self.x               = np.array(np.zeros((self.num_states, self.num_dump_steps), dtype=np.float64))
        
        self.set_initial_state(self.IC)
        self.time_ind[0]     = self.ii_global

        
    #---------------------------------------------------------------------------
    # Methods to be overwritten to do DA in an alternate space
    def get_state_vector(self, time_step, num_states_to_get, state_indices=None, state_space=None):
        if state_indices != None:
            return self.x[state_indices, time_step]
        else:
            return self.x[0:num_states_to_get, time_step]
    
    def set_state_vector(self, state, time_step, num_states_to_set):
        self.x[0:num_states_to_set, time_step] = state[0:num_states_to_set]

        
    #---------------------------------------------------------------------------
    # General methods
    def get_state(self, time_step, num_states_to_get=None, state_indices=None, state_space=None):
        num_states_to_get = self.sence_check_num_states(num_states_to_get)
        return self.get_state_vector(time_step, num_states_to_get, state_indices, state_space)

    def set_state(self, state, time_step, num_states_to_set=None):
        num_states_to_set = self.sence_check_num_states(num_states_to_set)
        if num_states_to_set>0:
            self.set_state_vector(state, time_step, num_states_to_set)

    def sence_check_num_states(self, num_states_to_get):
        if num_states_to_get is None:
            num_states_to_get = self.num_states
        else:
            num_states_to_get = min(self.num_states, num_states_to_get)
        return num_states_to_get

    
    #---------------------------------------------------------------------------
    # Decorated methods
    def get_current_state(self, num_states_to_get=None, state_indices=None, state_space=None):
        return self.get_state(self.ii, num_states_to_get, state_indices, state_space), self.ii

    def set_current_state(self, state, num_states_to_set=None):
        self.set_state(state, self.ii, num_states_to_set)
        
    def get_initial_state(self, num_states_to_get=None):
        return self.get_state(0, num_states_to_get)
        
    def set_initial_state(self, state, num_states_to_set=None):
        self.set_state(state, 0, num_states_to_set)

        
    #---------------------------------------------------------------------------
    def run(self,):
        for i in range(1,self.num_time_steps):
            self.step_state_forward()
    
    
    #---------------------------------------------------------------------------    
    def step_state_forward(self, forcing=None):

        if ((self.ii_global+1)%10000==0) or (self.ii_global+1==self.num_time_steps):
            print('Time step {0} of {1}'.format(self.ii_global+1,self.num_time_steps))
            
        # Get current values
        t0 = np.copy(self.time[self.ii])
        x0 = np.copy(self.x[:,self.ii])

        if self.ii==-1:
            # Overlapping from previous dump
            self.time[:]        = 0.0
            self.time_ind[:]    = 0
            self.x[:,:]         = 0.0
            
        # Step state forward and assign new values
        self.ii                += 1
        self.ii_global         += 1
        self.time[self.ii]      = t0 + self.dt
        self.time_ind[self.ii]  = self.ii_global
        
        if self.forced == False:
            if self.temporal_integration_method.lower() == 'runge-kutta':
                k1 = self.dt*self.calculate_time_derivative(x0,        time=t0)
                k2 = self.dt*self.calculate_time_derivative(x0+k1/2.0, time=t0+self.dt/2.0)
                k3 = self.dt*self.calculate_time_derivative(x0+k2/2.0, time=t0+self.dt/2.0)
                k4 = self.dt*self.calculate_time_derivative(x0+k3,     time=t0+self.dt)
                self.x[:,self.ii] = x0 + (k1 + 2.0*k2 + 2.0*k3 + k4)/6.0
            elif self.temporal_integration_method.lower() == 'euler':
                dx = self.dt*self.calculate_time_derivative(x0,        time=t0)
                self.x[:,self.ii] = x0 + dx*self.dt
            else:
                print('FATAL : undefined temporal integration method')
                sys.exit()
        else:
            if self.temporal_integration_method.lower() == 'runge-kutta':
                k1 = self.dt*self.calculate_time_derivative_forced(x0,        time=t0,             forcing=forcing[:,self.ii-1])
                k2 = self.dt*self.calculate_time_derivative_forced(x0+k1/2.0, time=t0+self.dt/2.0, forcing=forcing[:,self.ii-1])
                k3 = self.dt*self.calculate_time_derivative_forced(x0+k2/2.0, time=t0+self.dt/2.0, forcing=forcing[:,self.ii-1])
                k4 = self.dt*self.calculate_time_derivative_forced(x0+k3,     time=t0+self.dt,     forcing=forcing[:,self.ii])
                self.x[:,self.ii] = x0 + (k1 + 2.0*k2 + 2.0*k3 + k4)/6.0
            elif self.temporal_integration_method.lower() == 'euler':
                dx = self.dt*self.calculate_time_derivative_forced(x0, time=t0,  forcing=forcing[:,self.ii-1])
                self.x[:,self.ii] = x0 + dx*self.dt
            else:
                print('FATAL : undefined temporal integration method')
                sys.exit()
            
            
        # Add on bias fields
        self.x[:,self.ii] = self.x[:,self.ii] + self.bias + self.amplitude*np.cos(2.0*np.pi*t0/self.period)

        # Dump data and reset counter
        if (self.ii==self.num_dump_steps-1) or (self.ii_global==self.num_time_steps):
            self.dump_data()
            if self.ii < self.num_time_steps-1:
                self.ii         = -1       
        
    #---------------------------------------------------------------------------    
    def dump_data(self, ):
        if self.output_dir is not None:
            ds_out                     = xr.Dataset()
            ds_out['states']           = xr.DataArray( self.states,   coords=[self.states],   dims=['states'])
            ds_out['time_ind']         = xr.DataArray( self.time_ind, coords=[self.time_ind], dims=['time_ind'])
            ds_out['time']             = xr.DataArray( self.time,                             dims=['time_ind'])
            ds_out['x']                = xr.DataArray( self.x,                                dims=['states','time_ind'])
            
            if self.num_steps_in_period is not None:
                ds_out['num_steps_in_period'] = xr.DataArray( self.num_steps_in_period, coords=[self.states],   dims=['states'])

            output_filename = self.output_dir + '/x.{0:010d}'.format(self.ii_global) + '.nc'
            print('   writing {0} to disk'.format(output_filename))
            if not os.path.exists(self.output_dir):
                os.makedirs(self.output_dir)
            ds_out.to_netcdf(output_filename)
            ds_out.close()
            del ds_out
                        
        
    #---------------------------------------------------------------------------    
    def plot(self, tmin=None, tmax=None):
        if tmin is None:
            tmin = self.time[0]
        if tmax is None:
            tmax = self.time[-1]            
        plt.figure();
        plt.subplot(5,1,1); 
        plt.ylabel('states'); 
        plt.xlabel('time'); 
        plt.plot(self.time, self.x[:,:].T); 
        plt.tight_layout()
    
    
    #---------------------------------------------------------------------------
    def unimplemented_method_error(self,):
        print('Unimplemented method')
        sys.exit
    
    
    #---------------------------------------------------------------------------    
    def calculate_time_derivative(self, x):
        # This needs to be codified for each specific model
        self.unimplemented_method_error()

    #---------------------------------------------------------------------------    
    def calculate_time_derivative_forced(self, x, forcing):
        # This needs to be codified for each specific model
        self.unimplemented_method_error()

    #---------------------------------------------------------------------------    
    def calculate_matrix_cocycle(self, x):
        # This needs to be codified for each specific model
        self.unimplemented_method_error()

    #---------------------------------------------------------------------------    
    def calculate_CLV_numerically(self, A, Nk, M, Q=None, w_f=1):
        k = 0
        dim = self.num_states
        U = np.array(np.zeros((dim,dim,len(Nk)-1), dtype = np.float64))
        N = M
        
        for nn in Nk:
            Psi = np.identity(dim)
            i = 0
            while i < M:
                Psi = np.matmul(A[:,:,nn+i],Psi)
                Psi = Psi/linalg.norm(Psi)
                i += 1
            u, s, v = linalg.svd(Psi)
            v = v.T.conj()
            order = np.argsort(s)
            order = order[::-1]
            v = v[:,order]
            if nn == 0:
                CLV = v/linalg.norm(v,axis=0)
            else:
                U[:,:,k] = v/linalg.norm(v,axis=0)
                k +=1
            if nn == M:
                kstart = k - 1
            #print('Calculating subspace {0} of {1}'.format(k, len(Nk)))
        
        k = 0
        for nn in np.arange(0,N+1):
            CLV = np.matmul(A[:,:,nn],CLV)
            CLV = CLV/linalg.norm(CLV,axis=0)
            if any(nk == nn+1 for nk in Nk):
                for jj in np.arange(0,dim):
                    for ii in np.arange(0,jj):
                        CLV[:,jj] = CLV[:,jj]-np.dot(CLV[:,jj],U[:,ii,k])*U[:,ii,k]
                        CLV[:,jj] = CLV[:,jj]/linalg.norm(CLV[:,jj])
                k += 1
            #print('Push forward step {0} of {1}'.format(nn+1, N)
        
        #k = kstart
        #C = CLV
        #GR = np.array(np.zeros((dim,N+1), dtype = np.float64))
        #for nn in np.arange(0,N+1):
        #    NCovLyap = linalg.norm(C,axis=0)
        #    C = np.matmul(A[:,:,nn+N],C)
        #    if any(nk == nn+1 for nk in Nk):
        #        for jj in np.arange(0,dim):
        #                for ii in np.arange(0,jj):
        #                        C[:,jj] = C[:,jj]-np.dot(C[:,jj],U[:,ii,k])*U[:,ii,k]
        #        k += 1
        #    GR[:,nn] = 1/NCovLyap*(linalg.norm(C,axis=0)-NCovLyap)
        #    C = C/linalg.norm(C,axis=0)
            #print('Push forward step {0} of {1}'.format(nn+1, N)
        
        #Lyaps = 1/self.dt*np.mean(GR,axis=1)
        #order2 = np.argsort(Lyaps)
        #order2 = order2[::-1]
        #Lyaps = Lyaps[order2]
        #CLV   = CLV[:,order2]
        
        #Q_past = None
        
        if Q is None:
            Q = np.identity(dim)
        orthsteps = len(Nk)-1
        Rdiag = np.array(np.zeros((dim,orthsteps), dtype = np.float64))
        k = 0
        for nn in np.arange(0,N+1):
            Q = np.matmul(A[:,:,nn],Q)
            if any(nk == nn+1 for nk in Nk):
                Q , Rj = linalg.qr(Q)
                Rj = np.diag(Rj)
                l = np.where(Rj<0)
                ind = l[0]
                for ii in ind:
                    Q[:,ii] = -1*Q[:,ii]
                Rj = abs(Rj)
                Rdiag[:,k] = Rj
                k += 1
            if nn == w_f-1:
                Q_past, Rj = linalg.qr(Q) 
                Rj = np.diag(Rj)
                l = np.where(Rj<0)
                ind = l[0]
                for ii in ind:
                    Q_past[:,ii] = -1*Q_past[:,ii]
        Lambda = np.sum(np.log(Rdiag),axis=1)/N
        Lyaps = Lambda/self.dt
        order2 = np.argsort(Lyaps)
        order2 = order2[::-1]
        Lyaps = Lyaps[order2]
        
        #CLV = CLV[:,order2]
                  
        return CLV, Lyaps, Q_past

    #---------------------------------------------------------------------------    
    def calculate_BLV_numerically(self, A, Nk, M, Q=None, w_f=1):
        k = 0
        dim = self.num_states
        N = Nk[-1]
        
        
        #Psi = np.identity(dim)
        #i = 0
        #while i < M:
        #    Psi = np.matmul(A[:,:,i],Psi)
        #    Psi = Psi/linalg.norm(Psi)
        #    i += 1
        #u, s, v = linalg.svd(Psi)
        #order = np.argsort(s)
        #order = order[::-1]
        #v = v[:,order]
        #BLV = v/linalg.norm(v,axis=0)
            #print('Calculating subspace {0} of {1}'.format(k, len(Nk)))
        
        if Q is None:
            Q = np.identity(dim)
        orthsteps = len(Nk)-1
        Rdiag = np.array(np.zeros((dim,orthsteps), dtype = np.float64))

        for nn in np.arange(0,N):
            Q = np.matmul(A[:,:,nn],Q)
            if any(nk == nn+1 for nk in Nk):
                Q , Rj = linalg.qr(Q)
                Rj = np.diag(Rj)
                l = np.where(Rj<0)
                ind = l[0]
                for ii in ind:
                    Q[:,ii] = -1*Q[:,ii]
                Rj = abs(Rj)
                Rdiag[:,k] = Rj
                k += 1
            if nn == w_f-1:
                Q_past, Rj = linalg.qr(Q) 
                Rj = np.diag(Rj)
                l = np.where(Rj<0)
                ind = l[0]
                for ii in ind:
                    Q_past[:,ii] = -1*Q_past[:,ii]
        Lambda = np.sum(np.log(Rdiag),axis=1)/N
        Lyaps = Lambda/self.dt
        order2 = np.argsort(Lyaps)
        order2 = order2[::-1]
        Lyaps = Lyaps[order2]
        BLV   = Q[:,order2]
                  
        return BLV, Lyaps, Q_past
    
    
class EnsembleKalmanFilter(object):

    #---------------------------------------------------------------------------
    def __init__(self, control_model, forecast_ensemble, forecast_window=10, kf_type='EnKF', H=None, Q=None, D_obs=None, D=None, num_model_states_to_update=None, inflation_factor=None, sigma=None, alpha=None,obs_indices=None, state_space=None, num_unst=None, spinup_window=0, adapt_infl=False, dynamics=False,a_shadow=None):
        # ddt(x_t) = f(x_t) + w_t ; w_t~N(0,Q)
        #     y_t  = h(x_t) + v_T ; v_t~N(0,D) ; h(x_t) simplified to H*x
        
        self.control_model     = control_model                                                           # Control model used for observations        
        self.forecast_ensemble = forecast_ensemble                                                       # Ensemble of forecasts with unique initial conditions and potentially parameters
        self.kf_type           = kf_type                                                                 # Type of Ensemble Kalman Filter i.e. 'EnKF', 'ETKF', 'DEnKF'
        self.num_members       = len(self.forecast_ensemble)                                             # Number of ensemble members
        
        self.num_model_states  = self.control_model.num_states                                           # Number of model states
        self.num_model_states_to_update = num_model_states_to_update                                     # Number of model states to update
        if self.num_model_states_to_update is None:
            self.num_model_states_to_update = self.num_model_states
            
        self.num_states        = self.num_model_states                                                   # Total number of states i.e. model states
        
        if D is not None:
            self.num_observations = np.shape(D)[0]                                                       # Number of observations
        else:
            self.num_observations = self.num_states
        self.forecast_window   = forecast_window                                                         # Number of timesteps of forecasts between analyses
        self.spinup_window     = spinup_window
        self.num_analyses      = int(np.floor((self.control_model.num_time_steps-self.spinup_window)/self.forecast_window))-1 # Number of analyses
        self.num_time_steps    = self.spinup_window+self.num_analyses*self.forecast_window + 1           # Number of timesteps
        self.dt                = self.control_model.dt                                                   # Time step size
        
        if H is not None:
            self.H = H                                                                                   # Observational operator
        elif obs_indices is not None:
            Htemp = np.array(np.zeros((self.num_observations, self.num_states)), dtype=np.float64)
            ind = 0
            for ii in obs_indices:
                Htemp[ind,ii] = 1
                ind += 1
            self.H = Htemp
        else:
            self.H = np.array(np.eye(self.num_observations, self.num_states), dtype=np.float64) 

        if obs_indices is not None:
            self.obs_indices  = obs_indices
        else:
            self.obs_indices  = list(range(0,self.num_observations))
            
        if D is not None:
            self.D = D                                                                                   # Esimated observational error covariance
        else:
            self.D = np.array(np.eye((self.num_observations), dtype=np.float64))
        
        if D_obs is not None:
            self.D_obs = D_obs                                                                           # Actual observational error covariance
        else:
            self.D_obs = np.array(np.zeros((self.num_observations,self.num_observations), dtype=np.float64))
            
        if Q is not None:
            self.Q = Q                                                                                   # Process error covariance, only used in covariance update of standard KF
        else:
            self.Q = np.array(np.eye((self.num_states), dtype=np.float64))
        
        # Designate state space to perform Kalman filtering
        self.state_space = state_space
        self.Q_p         = np.identity(self.num_states)
        self.CLV         = None
        self.Lyaps       = None
        self.dimKY       = None
        self.entKS       = None
        
        if num_unst is None:
            self.num_unst = self.num_states
        else:
            self.num_unst = num_unst              # number of unstable and zero lyap exponents
        
        if self.num_unst == 'var':
            self.num_unst_DA = np.array(np.zeros(self.num_analyses, dtype=np.float64))
        
        self.W           = np.array(np.zeros((self.num_states,self.num_members,self.num_analyses), dtype=np.float64))
        self.dynamics    = dynamics

        if a_shadow is not None:
            self.shadow_obs = True
            self.shadow_model        = copy.deepcopy(self.control_model)
            self.shadow_model.forced = True
            self.shadow_model.IC     = self.control_model.IC + np.random.randn(9)
            self.shadow_model.alphas = a_shadow
        else:
            self.shadow_obs = False
        
        # Parameters to maintain spread
        self.inflation_factor  = inflation_factor                                                        # Inflate the anomalies by this factor at each analysis
        self.adapt_infl        = adapt_infl                                                              # Adaptive inflation
        self.sigma             = sigma                                                                   # Variance of stochastic forcing
        self.alpha             = alpha                                                                   # Decorrelation factor of stochastic forcing
        self.initialise_noise()
        
        self.allocate_memory()
        
    #---------------------------------------------------------------------------
    def initialise_noise(self,):
        if (self.alpha is not None) and (self.sigma is not None):
            self.noise             = np.array(np.zeros((self.num_states,self.num_members, self.num_analyses),dtype=np.float64))
            self.rho               = np.array(np.ones(self.num_states),dtype=np.float64)                   # Variance scaling parameter
            rho_squared = (1.0 - self.alpha)**2.0 / ( 1.0 - 2.0*self.dt*self.alpha - self.alpha**2.0 + 2.0*self.dt*(self.alpha**(1.0/self.dt+1.0)) )
            for ii in range(0,self.num_states):
                if rho_squared[ii] > 0.0:
                    self.rho[ii] = np.sqrt(rho_squared[ii])
                else:
                    print('WARNING : reverting back to white noise due to negative rho squared : state={0} ; rho^2={1} ; alpha={2} ; sigma={3} ; dt={4}'.format(ii, rho_squared[ii], self.alpha[ii], self.sigma[ii], self.dt))
                    self.alpha[ii] = 0.0
                    self.rho[ii]   = 1.0
            self.noise[:,:,0] = np.random.normal(size=(self.num_states,self.num_members))
            
            
    #---------------------------------------------------------------------------
    def allocate_memory(self,):
        self.time_f       = np.array(np.zeros((self.num_time_steps), dtype=np.float64))                                       # Time of each forecast
        self.time_f[0]    = self.control_model.time[0]
        self.time_a       = np.array(np.zeros((self.num_analyses), dtype=np.float64))                                         # Time of each analysis

        self.x_f          = np.array(np.zeros((self.num_states, self.num_members, self.num_time_steps), dtype=np.float64))    # Ensemble of forecasts
        for ee in range(0, self.num_members):
            self.x_f[:,ee,0] = self.forecast_ensemble[ee].get_initial_state(self.num_model_states)
                        
        self.x_a          = np.array(np.zeros((self.num_states, self.num_members, self.num_analyses), dtype=np.float64))      # Ensemble of analyses        
        self.x_control    = np.array(np.zeros((self.num_states, self.num_time_steps), dtype=np.float64))                      # Control simulation from which observations are taken
        self.d            = np.array(np.zeros((self.num_observations, self.num_analyses), dtype=np.float64))                  # Observations
        self.x_innovation = np.array(np.zeros((self.num_observations, self.num_members, self.num_analyses), dtype=np.float64))# Innovation, difference between observations and observed model state
        self.x_increment  = np.array(np.zeros((self.num_states, self.num_members, self.num_analyses), dtype=np.float64))      # Increment

        self.x_f_ensavg   = np.array(np.zeros((self.num_states, self.num_time_steps), dtype=np.float64))                      # Ensemble averaged forecasts
        self.x_a_ensavg   = np.array(np.zeros((self.num_states, self.num_analyses), dtype=np.float64))                        # Ensemble averaged analyses
        self.x_innovation_ensavg = np.array(np.zeros((self.num_observations, self.num_analyses), dtype=np.float64))           # Ensemble averaged innovation
        self.x_increment_ensavg = np.array(np.zeros((self.num_states, self.num_analyses), dtype=np.float64))                  # Ensemble averaged increment

        self.P_f          = np.array(np.zeros((self.num_states, self.num_states, self.num_time_steps), dtype=np.float64))     # State forecast covariance
        self.P_a          = np.array(np.zeros((self.num_states, self.num_states, self.num_analyses), dtype=np.float64))       # State analysis covariance

        self.K            = np.array(np.zeros((self.num_states, self.num_observations, self.num_analyses), dtype=np.float64)) # Kalman gain
            
            
    #---------------------------------------------------------------------------
    def do_assimilation(self,):
        if self.spinup_window != 0:
            num_spinup_steps = int(np.floor(self.spinup_window/self.forecast_window))
            print('Computing spinup forecasts')
            for forecast_index in range(0,num_spinup_steps):
                forecast_start_index = forecast_index*self.forecast_window + 1         # Plus one since initial condition is index 0
                forecast_end_index   = forecast_start_index + self.forecast_window - 1 # Minus one since the loops in functions below add one
            
                self.do_forecast(forecast_start_index, forecast_end_index)
            
                self.calculate_forecast_statistics(forecast_start_index, forecast_end_index)
            
                self.prepare_observations(forecast_start_index, forecast_end_index, forecast_index)
            
        for analysis_index in range(0,self.num_analyses):
            if np.mod(analysis_index,100) == 0:
                print('Processing cycle {0} of {1}'.format(analysis_index+1, self.num_analyses))
            
            forecast_start_index = self.spinup_window + analysis_index*self.forecast_window + 1         # Plus one since initial condition is index 0
            forecast_end_index   = forecast_start_index + self.forecast_window - 1 # Minus one since the loops in functions below add one
            
            self.do_forecast(forecast_start_index, forecast_end_index)
            
            self.calculate_forecast_statistics(forecast_start_index, forecast_end_index)
            
            self.prepare_observations(forecast_start_index, forecast_end_index, analysis_index)
            
            self.calculate_CLVs()
            
            self.calculate_increment_and_update_state(analysis_index, forecast_end_index)
            
            self.apply_inflation(analysis_index)
            
            self.apply_stochastic_perturbations(analysis_index)
            
            self.initialise_model(analysis_index)

            
    #---------------------------------------------------------------------------
    def do_forecast(self, t0, t1):
        for jj in range(t0, t1+1):
            for ee in range(0, self.num_members):
                self.forecast_ensemble[ee].step_state_forward()
                forecast_state, ii = self.forecast_ensemble[ee].get_current_state(num_states_to_get=self.num_model_states)
                if ii != jj:
                    print('Error in time indexing of forecast member={0} : ii={1} jj={2}'.format(ee,ii,jj))
                    sys.exit()
                
                self.x_f[:,ee,jj] = forecast_state
                
            self.time_f[jj] = self.forecast_ensemble[0].time[jj]

        
    #---------------------------------------------------------------------------
    def calculate_forecast_statistics(self, t0, t1):
        Z_f = np.array(np.zeros((self.num_states, self.num_members), dtype=np.float64))     # Ensemble of forecast perturbations
        for jj in range(t0, t1+1):
            self.x_f_ensavg[:,jj] = np.mean(self.x_f[:,:,jj], axis=1)                     # Ensemble average forecast
            for ee in range(0, self.num_members):
                Z_f[:,ee] = ( self.x_f[:,ee,jj] - self.x_f_ensavg[:,jj] ) / np.sqrt(self.num_members-1)
            self.P_f[:,:,jj] = np.matmul(Z_f, Z_f.T)                                      # State forecast covariance

            
    #---------------------------------------------------------------------------
    def prepare_observations(self, t0, t1, obs_index):
        for jj in range(t0, t1+1):
            self.control_model.step_state_forward()
            control_state, ii = self.control_model.get_current_state(num_states_to_get=self.num_model_states)
            if ii != jj:
                print('Error in time indexing of control : ii={0} jj={1}'.format(ii,jj))
                sys.exit()
            self.x_control[:,jj] = control_state
            time_ref             = self.control_model.time[jj]
            if self.shadow_obs == True:
                self.shadow_model.step_state_forward(forcing=self.x_control)
        if self.shadow_obs == True:
            obs_state = self.shadow_model.get_current_state(num_states_to_get=self.num_model_states)[0]
            self.d[:,obs_index] = np.matmul(self.H, obs_state)
        else:
            self.d[:,obs_index] = np.matmul(self.H, self.x_control[:,jj]) + np.random.normal(size=self.num_observations)*np.sqrt(np.diag(self.D_obs))        
        self.time_a[obs_index]   = time_ref
                    
     
    #---------------------------------------------------------------------------
    def calculate_CLVs(self, ):  # change to calculate_CLVs
        state_space = self.state_space
        if (state_space == 'CLV') or (self.dynamics == True):
            shell_model = copy.deepcopy(self.control_model)
            #ii = self.forecast_ensemble[0].get_current_state(num_states_to_get=self.num_model_states)[1]
            ii = self.control_model.get_current_state(num_states_to_get=self.num_model_states)[1]
        
            state_hist = self.x_f_ensavg[:,:ii+1]
            #state_hist = self.control_model.x[:,:ii+1]
            Nk         = shell_model.Nk
            N          = shell_model.Nk[-1]
            M          = shell_model.M
            state_traj = np.array(np.zeros((self.num_model_states,N+M), dtype=np.float64))
            
            #state_traj[:,0:M-1] = state_hist[:,-M:-1]
            state_traj[:,:M+1] = state_hist[:,-M-1:]
            ind = M+1
            current_time = ii*self.dt

            # Create trajectory needed for CLV calculation
            for tt in np.linspace(current_time,current_time+(M-1)*self.dt,num=M-1):
                x0 = state_traj[:,ind-1]
                t0 = tt
                k1 = self.dt*shell_model.calculate_time_derivative(x0,        time=t0)
                k2 = self.dt*shell_model.calculate_time_derivative(x0+k1/2.0, time=t0+self.dt/2.0)
                k3 = self.dt*shell_model.calculate_time_derivative(x0+k2/2.0, time=t0+self.dt/2.0)
                k4 = self.dt*shell_model.calculate_time_derivative(x0+k3,     time=t0+self.dt)
                state_traj[:,ind] = x0 + (k1 + 2.0*k2 + 2.0*k3 + k4)/6.0
                ind +=1

            # Calculate matrix cocycle needed
            tlims          = np.array([0, (N+M)*self.dt])
            matrix_cocycle = shell_model.calculate_matrix_cocycle(state_traj,tlims = tlims)
            
            # Calculate CLVs
            w_f = self.forecast_window
            Q_p = self.Q_p
            CLV, Lyaps, Q_p = shell_model.calculate_CLV_numerically(matrix_cocycle,Nk,M,Q=Q_p,w_f=w_f)
            CLV             = np.expand_dims(CLV,axis=2)
            Lyaps           = np.expand_dims(Lyaps,axis=1)
            
            self.Q_p = Q_p
            
            # calculate Kaplan-Yorke dimension
            i_min = self.num_states-1
            for ll in np.arange(1,self.num_states+1):
                S = np.sum(Lyaps[:ll,0])
                if S<0:
                    i_min = ll-1
                    break
            
            dimKY = i_min + np.sum(Lyaps[:i_min,0])/abs(Lyaps[i_min,0])
            dimKY = np.array([dimKY])
            
            # calculate Kolmogorov-Sinai entropy
            for ll in np.arange(0,self.num_states):
                Lyap_i = Lyaps[ll,0]
                if Lyap_i<0:
                    i_min = ll
                    break
            entKS = np.sum(Lyaps[:i_min,0])
            entKS = np.array([entKS])
            
            if self.CLV is None:
                self.CLV   = CLV
                self.Lyaps = Lyaps
                self.dimKY = dimKY
                self.entKS = entKS
            else:
                self.CLV   = np.append(self.CLV,CLV,axis=2)
                self.Lyaps = np.append(self.Lyaps,Lyaps,axis=1)
                self.dimKY = np.append(self.dimKY,dimKY)
                self.entKS = np.append(self.entKS,entKS)
        elif (state_space == 'BLV'):
            shell_model = copy.deepcopy(self.control_model)
            ii = self.forecast_ensemble[0].get_current_state(num_states_to_get=self.num_model_states)[1]
        
            state_hist = self.x_f_ensavg[:,:ii+1]
            Nk         = shell_model.Nk
            N          = shell_model.Nk[-1]
            M          = shell_model.M
            state_traj = np.array(np.zeros((self.num_model_states,N), dtype=np.float64))
            
            state_traj[:,0:N] = state_hist[:,-N:]
            ind = N
            current_time = ii*self.dt

            # Calculate matrix cocycle needed
            tlims          = np.array([0, M*self.dt])
            matrix_cocycle = shell_model.calculate_matrix_cocycle(state_traj,tlims = tlims)
            
            # Calculate CLVs
            w_f = self.forecast_window
            Q_p = self.Q_p
            CLV, Lyaps, Q_p = shell_model.calculate_BLV_numerically(matrix_cocycle,Nk,M,Q=Q_p,w_f=w_f)
            CLV             = np.expand_dims(CLV,axis=2)
            Lyaps           = np.expand_dims(Lyaps,axis=1)
            
            self.Q_p = Q_p
            
            # calculate Kaplan-Yorke dimension
            i_min = self.num_states-1
            for ll in np.arange(1,self.num_states+1):
                S = np.sum(Lyaps[:ll,0])
                if S<0:
                    i_min = ll-1
                    break
            
            dimKY = i_min + np.sum(Lyaps[:i_min,0])/abs(Lyaps[i_min,0])
            dimKY = np.array([dimKY])
            
            # calculate Kolmogorov-Sinai entropy
            for ll in np.arange(0,self.num_states):
                Lyap_i = Lyaps[ll,0]
                if Lyap_i<0:
                    i_min = ll
                    break
            entKS = np.sum(Lyaps[:i_min,0])
            entKS = np.array([entKS])
            
            if self.CLV is None:
                self.CLV   = CLV
                self.Lyaps = Lyaps
                self.dimKY = dimKY
                self.entKS = entKS
            else:
                self.CLV   = np.append(self.CLV,CLV,axis=2)
                self.Lyaps = np.append(self.Lyaps,Lyaps,axis=1)
                self.dimKY = np.append(self.dimKY,dimKY)
                self.entKS = np.append(self.entKS,entKS)
                

    #---------------------------------------------------------------------------
    def calculate_increment_and_update_state(self, i_a, i_f):
        transform_methods = ['etkf','denkf','esrf']
        
        if self.kf_type.lower() == 'enkf':
            self.calculate_increment_and_update_state_using_perturbed_obs(i_a, i_f)
        elif self.kf_type.lower() in transform_methods:
            self.calculate_increment_and_update_state_using_transform_matrix(i_a, i_f)
        else:
            print('Undefined Kalman filtering method')
            sys.exit()

            
    #---------------------------------------------------------------------------
    def calculate_increment_and_update_state_using_perturbed_obs(self, i_a, i_f):  
        # Ensemble of forecast perturbations
        Z_f = np.array(np.zeros((self.num_states, self.num_members), dtype=np.float64))
        for ee in range(0, self.num_members):
            Z_f[:,ee] = ( self.x_f[:,ee,i_f] - self.x_f_ensavg[:,i_f] ) / np.sqrt(self.num_members-1)
        
        # Kalman update of the ensemble average
        if (self.state_space == 'CLV') or (self.state_space == 'BLV'):
            if self.num_unst == 'var':
                num_unst = min(int(np.ceil(self.dimKY[i_a])),9)
                self.num_unst_DA[i_a] = num_unst  
            else:
                num_unst = self.num_unst
            
            C     = self.CLV[:,0:num_unst,i_a]
            # find weighted matrix: Z_f = C*W => W = (C^T*C)^-1*C^T*Z_f
            # for taking inverse: condition number -ratio of the biggest singular value by the smallest > 0
            W = np.matmul(linalg.pinv(np.matmul(C.T,C)),np.matmul(C.T,Z_f))
            self.W[0:num_unst,:,i_a] = W[0:num_unst,:]
            CW = np.matmul(C,W)
            Pf = np.matmul(CW,CW.T)
        else:
            Pf = self.P_f[:,:,i_f]
        
        if self.adapt_infl == True:
            Pf_HT        = np.matmul(Pf*linalg.norm(self.P_f[:,:,i_f]), self.H.T)
        else:
            Pf_HT        = np.matmul(Pf, self.H.T)
        
        self.K[:,:,i_a]  = np.matmul(Pf_HT, np.linalg.inv(np.matmul(self.H, Pf_HT) + self.D))

        for ee in range(0, self.num_members):
            obs                         = self.d[:,i_a] + np.random.normal(size=self.num_observations) * np.sqrt(np.diag(self.D))
            self.x_innovation[:,ee,i_a] = obs - np.matmul(self.H, self.x_f[:,ee,i_f])
            self.x_increment[:,ee,i_a]  = np.matmul(self.K[:,:,i_a], self.x_innovation[:,ee,i_a])
            self.x_a[:,ee,i_a]          = self.x_f[:,ee,i_f] + self.x_increment[:,ee,i_a]
        self.x_a_ensavg[:,i_a]          = np.mean(self.x_a[:,:,i_a],axis=1)
        self.x_innovation_ensavg[:,i_a] = np.mean(self.x_innovation[:,:,i_a],axis=1)
        self.x_increment_ensavg[:,i_a] = np.mean(self.x_increment[:,:,i_a],axis=1)
        
        # Calculate analysis covariance
        Z_a = np.array(np.zeros((self.num_states, self.num_members), dtype=np.float64))
        for ee in range(0, self.num_members):
            Z_a[:,ee] = ( self.x_a[:,ee,i_a] - self.x_a_ensavg[:,i_a] ) / np.sqrt(self.num_members-1)
        self.P_a[:,:,i_a] = np.matmul(Z_a, Z_a.T)
        
            
    #---------------------------------------------------------------------------
    def calculate_increment_and_update_state_using_transform_matrix(self, i_a, i_f):
        # Ensemble of forecast perturbations
        Z_f = np.array(np.zeros((self.num_states, self.num_members), dtype=np.float64))
        for ee in range(0, self.num_members):
            Z_f[:,ee] = ( self.x_f[:,ee,i_f] - self.x_f_ensavg[:,i_f] ) / np.sqrt(self.num_members-1)
        
        # Kalman update of the ensemble average
        if (self.state_space == 'CLV') or (self.state_space == 'BLV'):
            if self.num_unst == 'var':
                num_unst = min(int(np.ceil(self.dimKY[i_a])),9)
                self.num_unst_DA[i_a] = num_unst  
            else:
                num_unst = self.num_unst
            
            C     = self.CLV[:,0:num_unst,i_a]
            # find weighted matrix: Z_f = C*W => W = (C^T*C)^-1*C^T*Z_f
            # for taking inverse: condition number -ratio of the biggest singular value by the smallest > 0
            W = np.matmul(linalg.pinv(np.matmul(C.T,C)),np.matmul(C.T,Z_f))
            self.W[0:num_unst,:,i_a] = W[0:num_unst,:]
            CW = np.matmul(C,W)
            Pf = np.matmul(CW,CW.T)
        else:
            Pf = self.P_f[:,:,i_f]
        
        if self.adapt_infl == True:
            Pf_HT        = np.matmul(Pf*linalg.norm(self.P_f[:,:,i_f]), self.H.T)
        else:
            Pf_HT        = np.matmul(Pf, self.H.T)

        self.K[:,:,i_a]  = np.matmul(Pf_HT, np.linalg.inv(np.matmul(self.H, Pf_HT) + self.D))
        
        for ee in range(0, self.num_members):
            self.x_innovation[:,ee,i_a] = self.d[:,i_a] - np.matmul(self.H, self.x_f[:,ee,i_f])
        self.x_innovation_ensavg[:,i_a] = self.d[:,i_a] - np.matmul(self.H, self.x_f_ensavg[:,i_f])
        
        self.x_increment_ensavg[:,i_a]  = np.matmul(self.K[:,:,i_a], self.x_innovation_ensavg[:,i_a])
        self.x_a_ensavg[:,i_a]          = self.x_f_ensavg[:,i_f] + self.x_increment_ensavg[:,i_a]

        if self.kf_type.lower() == 'esrf':
            #if self.adapt_infl == True:
            #    K_bg = np.matmul(np.matmul(Pf, self.H.T), np.linalg.inv(np.matmul(self.H, np.matmul(Pf, self.H.T)) + self.D))
            #    TL   = np.real(scipy.linalg.sqrtm( np.eye(self.num_states) - np.matmul(K_bg, self.H) ))
            #else:
            TL = np.real(scipy.linalg.sqrtm( np.eye(self.num_states) - np.matmul(self.K[:,:,i_a], self.H) ))
            Z_a = np.matmul(TL, Z_f)
        elif self.kf_type.lower() == 'denkf':
            TL = np.eye(self.num_states) - np.matmul(self.K[:,:,i_a], self.H)/2.0
            Z_a = np.matmul(TL, Z_f)
        elif self.kf_type.lower() == 'etkf':
            S   = np.matmul(np.linalg.inv(np.real(scipy.linalg.sqrtm(self.D))),np.matmul(self.H,Z_f))
            if self.num_members <= self.num_observations:
                TR  = np.real(scipy.linalg.sqrtm( np.linalg.inv(np.eye(self.num_members) +  np.matmul(S.T,S) )))
            else:
                TR  = np.real(scipy.linalg.sqrtm(np.eye(self.num_members) - np.matmul(S.T,np.matmul(np.linalg.inv(np.eye(self.num_observations) +  np.matmul(S,S.T)),S)) )) 
            Z_a = np.matmul(Z_f,TR)
                               
        # Update analysis
        self.P_a[:,:,i_a] = np.matmul(Z_a, Z_a.T)             # Analysis covariance
        for ee in range(0, self.num_members):
            self.x_a[:,ee,i_a] = self.x_a_ensavg[:,i_a]       # Analysis ensemble mean
        self.x_a[:,:,i_a] += Z_a*np.sqrt(self.num_members-1)  # Analysis ensemble perturbations
                                    
            
    #---------------------------------------------------------------------------
    def apply_inflation(self, i_a):
        if self.inflation_factor is not None:
            for ee in range(0, self.num_members):
                self.x_a[:,ee,i_a] = (self.x_a[:,ee,i_a] - self.x_a_ensavg[:,i_a])*self.inflation_factor + self.x_a_ensavg[:,i_a]
            self.P_a[:,:,i_a] = self.P_a[:,:,i_a] * (self.inflation_factor**2.0)

            
    #---------------------------------------------------------------------------            
    def apply_stochastic_perturbations(self, i_a):
        if (self.sigma is not None) and (self.alpha is not None):
            for ee in range(0, self.num_members):
                self.noise[:,ee,i_a] = self.alpha*self.noise[:,ee,i_a-1] + np.sqrt(1.0-self.alpha**2.0)*np.random.normal(size=self.num_states)
                self.x_a[:,ee,i_a] += np.sqrt(self.dt) * self.rho * self.sigma * self.noise[:,ee,i_a]
        
        
    #---------------------------------------------------------------------------
    def initialise_model(self, i_a):
        for ee in range(0, self.num_members):            
            self.forecast_ensemble[ee].set_current_state(self.x_a[:,ee,i_a], num_states_to_set=self.num_model_states_to_update)
            

##################### Pena Kalnay Model #######################

class PenaKalnay2004(Model):

    #---------------------------------------------------------------------------
    def __init__(self, num_time_steps=10000, dt=0.01, IC=[-5.0, -5.0, 15.0, -5.0, -5.0, 15.0, -5.0, -5.0, 15.0],                  M = 0, Nk = 0,                  bias=None, amplitude=None, period=None,                  num_dump_steps=None, output_dir=None):
        
        # Lorenz attractor parameters
        # Note: r=0.8 converges to (0,0,0); r=2 converges to (1.63,1.63,1); r=21 almost periodic; r=28 chaotic; chaotic behaviour starts at r=21.3.
        self.r       = 28.0
        self.s       = 10.0
        self.b       = 8.0/3.0
        
        # Pena & Kalnay (2004) parameters
        self.Slow    = 1.0     # Slow system 1/S times larger in amplitude than the fast system
        self.tau     = 0.1     # Slow system 1/tau times slower than the fast system
        self.c       = 1.0     # Coupling between ocean and tropical atmosphere for x and y
        self.c_z     = 1.0     # Coupling between ocean and tropical atmosphere for z
        self.c_e     = 0.08    # Coupling between extra-tropical and tropical atmosphere
        self.k_1     = 10.0    # Uncentred parameter for fast atmosphere
        self.k_2     = -11.0   # Uncentred parameter for slow ocean
        self.M       = M       # Push forward steps for CLV calculation
        self.Nk      = Nk      # 1-D Array of reorthogonalization times during CLV calculation
        
        #self.CLV     = np.array(np.zeros((len(IC),len(IC)), dtype=np.float64))        # set up empty field
        
        Model.__init__(self, num_time_steps, dt, IC, bias=bias, amplitude=amplitude, period=period,                        num_dump_steps=num_dump_steps, output_dir=output_dir)


    #---------------------------------------------------------------------------    
    def calculate_time_derivative(self, x, time=None):
        # Get current state values
        x_e = x[0];        y_e = x[1];        z_e = x[2]; # Extra-tropical atmosphere
        x_t = x[3];        y_t = x[4];        z_t = x[5]; # Tropical atmosphere
        X   = x[6];        Y   = x[7];        Z   = x[8]; # Ocean
        
        # Calculate current state time derivative
        dx_e = self.s*(y_e - x_e)                                                        - self.c_e*(self.Slow*x_t + self.k_1)
        dy_e = self.r*x_e - y_e - x_e*z_e                                                + self.c_e*(self.Slow*y_t + self.k_1)
        dz_e = x_e*y_e - self.b*z_e
        
        dx_t = self.s*(y_t - x_t)                      - self.c*(self.Slow*X + self.k_2) - self.c_e*(self.Slow*x_e + self.k_1) 
        dy_t = self.r*x_t - y_t - x_t*z_t              + self.c*(self.Slow*Y + self.k_2) + self.c_e*(self.Slow*y_e + self.k_1)
        dz_t = x_t*y_t - self.b*z_t                    + self.c_z*Z
        
        dX   = self.tau*self.s*(Y - X)                 - self.c*(x_t + self.k_2)
        dY   = self.tau*(self.r*X - Y - self.Slow*X*Z) + self.c*(y_t + self.k_2)
        dZ   = self.tau*(self.Slow*X*Y - self.b*Z)     - self.c_z*z_t
        
        # Assign to output vector
        dx = np.array(np.zeros((self.num_states), dtype=np.float64))
        dx[0] = dx_e;      dx[1] = dy_e;      dx[2] = dz_e # Extra-tropical atmosphere
        dx[3] = dx_t;      dx[4] = dy_t;      dx[5] = dz_t # Tropical atmosphere
        dx[6] = dX;        dx[7] = dY;        dx[8] = dZ   # Ocean
        
        return dx

    #---------------------------------------------------------------------------    
    def calculate_Jacobian(self, traj, time):
         
        if time is not None:
            tind = int(time/self.dt)
            x = traj[:,tind]
        else:
            x = traj
        
        # Get current state values
        x_e = x[0];        y_e = x[1];        z_e = x[2]; # Extra-tropical atmosphere
        x_t = x[3];        y_t = x[4];        z_t = x[5]; # Tropical atmosphere
        X   = x[6];        Y   = x[7];        Z   = x[8]; # Ocean
        
        # Calculate current Jacobian
        L = np.array(np.zeros((self.num_states, self.num_states), dtype=np.float64))
        
        L[0,0] = -self.s;               L[1,0] = self.r-z_e;                      L[2,0] = y_e;
        L[0,1] = self.s;                L[1,1] = -1;                              L[2,1] = x_e;
        L[0,3] = -self.c_e*self.Slow;   L[1,2] = -x_e;                            L[2,2] = -self.b;
        L[1,4] = self.c_e*self.Slow;
        
        L[3,0] = -self.c_e*self.Slow;   L[4,2] = self.c_e*self.Slow;              L[5,3] = y_t;
        L[3,3] = -self.s;               L[4,3] = self.r-z_t;                      L[5,4] = x_t;
        L[3,4] = self.s;                L[4,4] = -1;                              L[5,5] = -self.b;
        L[3,6] = -self.c*self.Slow;     L[4,5] = -x_t;                            L[5,8] = self.c_z;
        L[4,7] = self.c*self.Slow
    
        L[6,3] = -self.c;               L[7,4] = self.c;                          L[8,5] = -self.c_z;
        L[6,6] = -self.s*self.tau;      L[7,6] = self.tau*(self.r-self.Slow*Z);   L[8,6] = self.tau*self.Slow*Y;
        L[6,7] = self.s*self.tau;       L[7,7] = -self.tau;                       L[8,7] = self.tau*self.Slow*X;
        L[7,8] = -self.tau*self.Slow*X;           L[8,8] = -self.tau*self.b;
        
        return L
    
    #---------------------------------------------------------------------------    
    def calculate_matrix_cocycle(self, x, tlims=None):
        
        if tlims is None:
            print('FATAL : undefined time limits for matrix cocycle calculation')
            sys.exit()
        
        trange = np.arange(tlims[0],tlims[1],self.dt)
        matrix_cocycle = np.array(np.zeros((self.num_states, self.num_states, len(trange)), dtype=np.float64))
        i = 0
        for tt in trange:
            L = self.calculate_Jacobian(x,time=tt)
            matrix_cocycle[:,:,i] = linalg.expm(L*self.dt)
            i += 1
            
        return matrix_cocycle

    #---------------------------------------------------------------------------    
    def calculate_time_derivative_forced(self, x, forcing, time=None):
        # Get current state values
        x_e = x[0];        y_e = x[1];        z_e = x[2]; # Extra-tropical atmosphere
        x_t = x[3];        y_t = x[4];        z_t = x[5]; # Tropical atmosphere
        X   = x[6];        Y   = x[7];        Z   = x[8]; # Ocean

        #a1  = 2.75;        a2  = 2.75;           a3  = 2.75;  
        #a1  = 2.5;        a2  = 0;           a3  = 2.5;
        #a1  = 2.75;        a2  = 0.75;           a3  = 0.75;
        a1 = self.alphas[0]; a2 = self.alphas[1]; a3 = self.alphas[2];
        # Calculate current state time derivative
        dx_e = self.s*(y_e - x_e)                                                        - self.c_e*(self.Slow*x_t + self.k_1)
        dy_e = self.r*x_e - y_e - x_e*z_e                                                + self.c_e*(self.Slow*y_t + self.k_1) + a1*(forcing[1]-y_e) 
        dz_e = x_e*y_e - self.b*z_e
        
        dx_t = self.s*(y_t - x_t)                      - self.c*(self.Slow*X + self.k_2) - self.c_e*(self.Slow*x_e + self.k_1) 
        dy_t = self.r*x_t - y_t - x_t*z_t              + self.c*(self.Slow*Y + self.k_2) + self.c_e*(self.Slow*y_e + self.k_1) + a2*(forcing[4]-y_t)
        dz_t = x_t*y_t - self.b*z_t                    + self.c_z*Z
        
        dX   = self.tau*self.s*(Y - X)                 - self.c*(x_t + self.k_2)
        dY   = self.tau*(self.r*X - Y - self.Slow*X*Z) + self.c*(y_t + self.k_2)                                               + a3*(forcing[7]-Y)
        dZ   = self.tau*(self.Slow*X*Y - self.b*Z)     - self.c_z*z_t
        
        # Assign to output vector
        dx = np.array(np.zeros((self.num_states), dtype=np.float64))
        dx[0] = dx_e;      dx[1] = dy_e;      dx[2] = dz_e # Extra-tropical atmosphere
        dx[3] = dx_t;      dx[4] = dy_t;      dx[5] = dz_t # Tropical atmosphere
        dx[6] = dX;        dx[7] = dY;        dx[8] = dZ   # Ocean
        
        return dx


##################### Lorenz63 Model #######################

class Threescroll(Model):

    #---------------------------------------------------------------------------
    def __init__(self, num_time_steps=10000, dt=0.01, IC=[0.1, 1.0, -0.1],M = 0, Nk = 0,bias=None, amplitude=None, period=None,num_dump_steps=None, output_dir=None):
        #IC=[1.618,-1.618,1.618] Doi: 10.3934/dcdsb.2021165
        # Lorenz attractor parameters
        # Note: r=0.8 converges to (0,0,0); r=2 converges to (1.63,1.63,1); r=21 almost periodic; r=28 chaotic; chaotic behaviour starts at r=21.3.
        self.a       = 32.48 
        self.b       = 45.84 
        self.c       = 1.18 
        self.d       = 0.13 
        self.e       = 0.57 
        self.f       = 14.7 
        
        
        self.M       = M       # Push forward steps for CLV calculation
        self.Nk      = Nk      # 1-D Array of reorthogonalization times during CLV calculation
        
        Model.__init__(self, num_time_steps, dt, IC, bias=bias, amplitude=amplitude, period=period, num_dump_steps=num_dump_steps, output_dir=output_dir)


    #---------------------------------------------------------------------------    
    def calculate_time_derivative(self, x, time=None):
        # Get current state values
        x_e = x[0];        y_e = x[1];        z_e = x[2];
        
        # Calculate current state time derivative
        dx_e = self.a * y_e - self.a * x_e + self.d * x_e * z_e
        dy_e = self.b * x_e + self.f * y_e - x_e * z_e
        dz_e = self.c * z_e + x_e * y_e - self.e * x_e * x_e

        # Assign to output vector
        dx = np.array(np.zeros((self.num_states), dtype=np.float64))
        dx[0] = dx_e;      dx[1] = dy_e;      dx[2] = dz_e 
        
        return dx
    
    #---------------------------------------------------------------------------    
    def calculate_Jacobian(self, traj, time):
         
        if time is not None:
            tind = int(time/self.dt)
            x = traj[:,tind]
        else:
            x = traj
        
        # Get current state values
        x_e = x[0];        y_e = x[1];        z_e = x[2];
        
        # Calculate current Jacobian
        L = np.array(np.zeros((self.num_states, self.num_states), dtype=np.float64))
        
        L[0,0] = -self.a + self.d * z_e;    L[0,1] = self.a;        L[0,2] = self.d * x_e;
        L[1,0] = self.b - z_e;              L[1,1] = self.f;        L[1,2] = - x_e;
        L[2,0] = y_e - 2.0 * self.e * x_e;  L[2,1] = x_e;           L[2,2] = self.c;                                                
                          
        return L
    
    #---------------------------------------------------------------------------    
    def calculate_matrix_cocycle(self, x, tlims=None):
        
        if tlims is None:
            print('FATAL : undefined time limits for matrix cocycle calculation')
            sys.exit()
        
        trange = np.arange(tlims[0],tlims[1],self.dt)
        matrix_cocycle = np.array(np.zeros((self.num_states, self.num_states, len(trange)), dtype=np.float64))
        i = 0
        for tt in trange:
            L = self.calculate_Jacobian(x,time=tt)
            matrix_cocycle[:,:,i] = linalg.expm(L*self.dt)
            i += 1
            
        return matrix_cocycle

    
##################### Coupled Lorenz #######################

class CoupledLorenz(Model):

    #---------------------------------------------------------------------------
    def __init__(self, num_time_steps=10000, dt=0.01, coupling='enso', IC=[-5.0, -5.0, 15.0,-5.0, -5.0, 15.0],                  M = 0, Nk = 0,                  bias=None, amplitude=None, period=None,                  num_dump_steps=None, output_dir=None):
        #self.coupling = coupling
        # Lorenz attractor parameters
        # Note: r=0.8 converges to (0,0,0); r=2 converges to (1.63,1.63,1); r=21 almost periodic; r=28 chaotic; chaotic behaviour starts at r=21.3.
        self.r       = 28.0
        self.s       = 10.0
        self.b       = 8.0/3.0
        
        # Pena & Kalnay (2004) parameters for various coupling senarios
        self.tau     = 0.1     # Slow system 1/tau times slower than the fast system
        
        if coupling == 'enso':  # parameters for an ENSO-like atmosphere-ocean systems
            self.Slow    = 1.0     # Slow system 1/S times larger in amplitude than the fast system
            self.c       = 1.0     # Coupling for x and y components
            self.c_z     = 1.0     # Coupling for z components
            self.k_1     = -11.0    # Uncentred parameter for fast system
            
        elif coupling == 'ET1':  # parameters for an extratropical atmosphere-ocean systems
            self.Slow    = 1.0     # Slow system 1/S times larger in amplitude than the fast system
            self.c       = 0.15     # Coupling for x and y components
            self.c_z     = 0.     # Coupling for z components
            self.k_1     = 10.0    # Uncentred parameter for fast system
            
        elif coupling == 'ET2':  # parameters for a more weakly coupled extratropical atmosphere-ocean system
            self.Slow    = 1.0     # Slow system 1/S times larger in amplitude than the fast system
            self.c       = 0.08     # Coupling for x and y components
            self.c_z     = 0.     # Coupling for z components
            self.k_1     = 10.0    # Uncentred parameter for fast system
            
        elif coupling == 'weather':  # parameters for a baroclinic atmosphere-ocean system
            self.Slow    = 0.1     # Slow system 1/S times larger in amplitude than the fast system
            self.c       = 0.15     # Coupling for x and y components
            self.c_z     = 0.     # Coupling for z components
            self.k_1     = 10.0    # Uncentred parameter for fast system
            
        else:
            print('Undefined coupling type')
            sys.exit()
        
        
        
        self.M       = M       # Push forward steps for CLV calculation
        self.Nk      = Nk      # 1-D Array of reorthogonalization times during CLV calculation
        
        #self.CLV     = np.array(np.zeros((len(IC),len(IC)), dtype=np.float64))        # set up empty field
        
        Model.__init__(self, num_time_steps, dt, IC, bias=bias, amplitude=amplitude, period=period, num_dump_steps=num_dump_steps, output_dir=output_dir)


    #---------------------------------------------------------------------------    
    def calculate_time_derivative(self, xi, time=None):
        # Get current state values
        x = xi[0];        y = xi[1];        z = xi[2]; # Atmosphere
        X = xi[3];        Y = xi[4];        Z = xi[5]; # Ocean
        
        # Calculate current state time derivative
        dx = self.s*(y - x)                            - self.c*(self.Slow*X + self.k_1)
        dy = self.r*x - y - x*z                        + self.c*(self.Slow*Y + self.k_1)
        dz = x*y - self.b*z                            + self.c_z*Z

        
        dX   = self.tau*self.s*(Y - X)                 - self.c*(x + self.k_1)
        dY   = self.tau*(self.r*X - Y - self.Slow*X*Z) + self.c*(y + self.k_1)
        dZ   = self.tau*(self.Slow*X*Y - self.b*Z)     - self.c_z*z
        
        # Assign to output vector
        dxi = np.array(np.zeros((self.num_states), dtype=np.float64))
        dxi[0] = dx;      dxi[1] = dy;      dxi[2] = dz # Atmosphere
        dxi[3] = dX;      dxi[4] = dY;      dxi[5] = dZ   # Ocean
        
        return dxi

    #---------------------------------------------------------------------------    
    def calculate_Jacobian(self, traj, time):
         
        if time is not None:
            tind = int(time/self.dt)
            xi = traj[:,tind]
        else:
            xi = traj
        
        # Get current state values
        x = xi[0];        y = xi[1];        z = xi[2]; # Atmosphere
        X = xi[3];        Y = xi[4];        Z = xi[5]; # Ocean
        
        # Calculate current Jacobian
        L = np.array(np.zeros((self.num_states, self.num_states), dtype=np.float64))
        
        L[0,0] = -self.s;               L[1,0] = self.r-z;                        L[2,0] = y;
        L[0,1] = self.s;                L[1,1] = -1;                              L[2,1] = x;
        L[0,3] = -self.c*self.Slow;     L[1,2] = -x;                              L[2,2] = -self.b;
        L[1,4] = self.c*self.Slow;                L[2,5] = self.c_z;
    
        L[3,0] = -self.c;               L[4,1] = self.c;                          L[5,2] = -self.c_z;
        L[3,3] = -self.s*self.tau;      L[4,3] = self.tau*(self.r-self.Slow*Z);   L[5,3] = self.tau*self.Slow*Y;
        L[3,4] = self.s*self.tau;       L[4,4] = -self.tau;                       L[5,4] = self.tau*self.Slow*X;
        L[4,5] = -self.tau*self.Slow*X;           L[5,5] = -self.tau*self.b;
        
        return L
    
    #---------------------------------------------------------------------------    
    def calculate_matrix_cocycle(self, x, tlims=None):
        
        if tlims is None:
            print('FATAL : undefined time limits for matrix cocycle calculation')
            sys.exit()
        
        trange = np.arange(tlims[0],tlims[1],self.dt)
        matrix_cocycle = np.array(np.zeros((self.num_states, self.num_states, len(trange)), dtype=np.float64))
        i = 0
        for tt in trange:
            L = self.calculate_Jacobian(x,time=tt)
            matrix_cocycle[:,:,i] = linalg.expm(L*self.dt)
            i += 1
            
        return matrix_cocycle


